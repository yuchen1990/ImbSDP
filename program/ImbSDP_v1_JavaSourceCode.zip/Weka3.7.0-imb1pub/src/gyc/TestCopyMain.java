package gyc;

import gyc.OverBoostM1;
import gyc.SMOTEBagging;
import gyc.UnderOverBoostM1;
import gyc.UnderOverSamplingClassifier;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import weka.attributeSelection.ASEvaluation;
import weka.attributeSelection.ASSearch;
import weka.attributeSelection.BestFirst;
import weka.attributeSelection.CfsSubsetEval;
import weka.classifiers.Classifier;
import weka.classifiers.CostMatrix;
import weka.classifiers.Evaluation;
import weka.classifiers.bayes.NaiveBayes;
import weka.classifiers.functions.Logistic;
import weka.classifiers.functions.SMO;
import weka.classifiers.keel.OverBagging2;
import weka.classifiers.keel.UnderBagging2;
import weka.classifiers.keel.UnderOverBagging;
import weka.classifiers.lazy.IBk;
import weka.classifiers.meta.AdaBoostM1;
import weka.classifiers.meta.Bagging;
import weka.classifiers.meta.FilteredClassifier;
import weka.classifiers.meta.MetaCost;
import weka.classifiers.rules.JRip;
import weka.classifiers.szb.RUSBoostM1;
import weka.classifiers.szb.SMOTEBoostM1;
import weka.classifiers.szb.SplitVote;
import weka.classifiers.trees.J48;
import weka.classifiers.trees.RandomForest;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.SelectedTag;
import weka.core.Utils;
import weka.core.converters.ConverterUtils.DataSource;
import weka.filters.szb.MyOverSample;
import weka.filters.szb.MySMOTE;
import weka.filters.szb.MyUnderSample;

public class TestCopyMain {

	private static Instances m_Data; // data set
	private static int m_folds=10; // number of folds
	private static int m_repeat=10; //m times n folds
	
	private static boolean m_AttribSelect1 = true;

	private static String sourceDir = "input/";
	private static String destDir = "output/";
	
	public TestCopyMain() {
		m_Data = null;
	}	
	
	/**
	 * ���ļ��ж�ȡ���ݼ����������ݼ����뵽m_Data��
	 */
	public static void generateData(String filename) {
		//System.out.println(filename);
		try {
			DataSource ds = new DataSource(filename);
			m_Data = ds.getDataSet();
			m_Data.setClassIndex(m_Data.numAttributes() - 1);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static Classifier getAttributeSelectedClassifier(Classifier modelClassifier) {
		weka.filters.supervised.attribute.AttributeSelection filter =
				new weka.filters.supervised.attribute.AttributeSelection();
		ASEvaluation evaluator = //new SymmetricalUncertAttributeSetEval();
				new CfsSubsetEval();
		ASSearch search = //new FASTSearch();
				//new FCBFSearch();
				new BestFirst();
		
		filter.setEvaluator(evaluator);
		filter.setSearch(search);
		
		FilteredClassifier fc = new FilteredClassifier();
		fc.setClassifier(modelClassifier);
		fc.setFilter(filter);
		return fc;
	}

	/**
	 * ��ʵ����content������ļ�filename��
	 */
	public static void outputResults(String filename, String content) {
		try {
			FileWriter writer = new FileWriter(filename, true);
			writer.write(content);
			writer.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * ͳ�����ݼ��ж�����ʵ����������ʵ���ı�ֵ
	 */
	public static double checkRatio(Instances inst) {
		int major = 0, minor = 0;
		for (int i = 0; i < inst.numInstances(); i++) {
			Instance ins = inst.instance(i);
			if (inst.classAttribute().isNominal()) {
				if (ins.classValue() == 0)
					minor++;
				else
					major++;
			} else if (inst.classAttribute().isNumeric()) {
				if (ins.classValue() > 0)
					minor++;
				else
					major++;
			}
		}

		return (double) major / minor;
	}
	
	
/*
 * combination of classification algorithm and imbalanced learning methods
 */
	public static Classifier get_learning_method(int learner_ID, int imb_ID){
				
		Classifier baseLearner = null;
		switch (learner_ID) {
		case 1:		//RF
			baseLearner = new RandomForest(); break;			
		case 2:		//SVM (smo)
			baseLearner = new SMO(); break;	
		case 3:		//Ripper
			baseLearner = new JRip();  break;
		case 4:		//IBk
			IBk ibk = new IBk();
			ibk.setKNN(5);
			baseLearner = ibk; break;
		case 5:		//LR
			baseLearner = new Logistic(); break;		
		case 6:		//NB
			baseLearner = new NaiveBayes(); break;	
		default: 	//C4.5
			baseLearner = new J48();
			break;
		}
		//	String[] learnerList={"C4.5", "RF", "SVM", "Ripper", "IBk", "LR", "NB"};
		
		if (m_AttribSelect1) {
			baseLearner= getAttributeSelectedClassifier(baseLearner);
		}
		
		//		String[] imbMethodList={"none", "Bag", "Bst", "US", "OS", "UOS", "SMOTE",
		//											"COS", "EM1v1", "UBag", "UOBag", "OBag", "SBag", "UBst", "OBst", "UOBst", "SBst"};
		int Vote = 1; /* ͶƱ���� */
		Classifier iclassifier= null;
		
		switch (imb_ID) {
		case 1://Bag
				Bagging bag = new Bagging();
				bag.setClassifier(baseLearner);
				bag.setNumIterations(10);
				iclassifier=bag;
			break;
		case 2://Bst
				AdaBoostM1 boost = new AdaBoostM1();
				boost.setClassifier(baseLearner);
				boost.setNumIterations(10);
				boost.setUseResampling(true);
				iclassifier=boost;
			break;
		case 3: //US
				FilteredClassifier fc3 = new FilteredClassifier();
				fc3.setClassifier(baseLearner);
				MyUnderSample us = new MyUnderSample();
				fc3.setFilter(us);
				iclassifier = fc3;
			break;
		case 4://OS
				FilteredClassifier fc4 = new FilteredClassifier();
				fc4.setClassifier(baseLearner);
				MyOverSample os = new MyOverSample();
				fc4.setFilter(os);
				iclassifier=fc4;
			break;
		case 5:	//UOS
				UnderOverSamplingClassifier fc5 = new UnderOverSamplingClassifier();
				fc5.setClassifier(baseLearner);
				fc5.setM_Percentage(0.5);
				iclassifier=fc5;
			break;		
		case 6:	//SMOTE
				FilteredClassifier fc6 = new FilteredClassifier();
				fc6.setClassifier(baseLearner);
				MySMOTE smote = new MySMOTE();
				fc6.setFilter(smote);
				iclassifier=fc6;
			break;		
		case 7:	//COS
				//need to define cost matrix in building progress
				iclassifier=baseLearner;
			break;		
		case 8:	//EM1v1
				SplitVote split=new SplitVote();
				split.setBaseClassifier(baseLearner);
				SelectedTag sel8 = new SelectedTag(Vote, split.TAGS_RULES);
				split.setCombinationRule(sel8);
				iclassifier=split;
			break;			
		case 9:	//UBag
				UnderBagging2 imbEnsemble9 = new UnderBagging2();
				imbEnsemble9.setBaseClassifier(baseLearner);
				SelectedTag sel9 = new SelectedTag(Vote, imbEnsemble9.TAGS_RULES);
				imbEnsemble9.setCombinationRule(sel9);
				iclassifier=imbEnsemble9;
			break;	
		case 10://OBag
				OverBagging2 imbEnsemble10 = new OverBagging2();
				imbEnsemble10.setBaseClassifier(baseLearner);
				SelectedTag sel10 = new SelectedTag(Vote, imbEnsemble10.TAGS_RULES);
				imbEnsemble10.setCombinationRule(sel10);
				iclassifier=imbEnsemble10;
			break;
		case 11://UOBag
				UnderOverBagging imbEnsemble11= new UnderOverBagging();
				imbEnsemble11.setBaseClassifier(baseLearner);
				SelectedTag sel11 = new SelectedTag(Vote, imbEnsemble11.TAGS_RULES);
				imbEnsemble11.setCombinationRule(sel11);
				iclassifier=imbEnsemble11;
			break;
		case 12://SBag
				SMOTEBagging imbEnsemble12 = new SMOTEBagging();
				imbEnsemble12.setClassifier(baseLearner);
				imbEnsemble12.setNumIterations(10);
				iclassifier=imbEnsemble12;
			break;
		case 13://UBst
				RUSBoostV2 rusboost = new RUSBoostV2();
				//RUSBoostM1 rusboost = new RUSBoostM1();
				rusboost.setClassifier(baseLearner);
				rusboost.setNumIterations(10);
				rusboost.setUseResampling(true);
				//rusboost.setDebug(true);
				iclassifier=rusboost;
			break;
		case 14://OBst
				OverBoostM1 imbEnsemble14 = new OverBoostM1();
				imbEnsemble14.setClassifier(baseLearner);
				imbEnsemble14.setNumIterations(10);
				imbEnsemble14.setUseResampling(true);
				iclassifier=imbEnsemble14;
			break;
		case 15://UOBst
				UnderOverBoostM1 imbEnsemble15 = new UnderOverBoostM1();
				imbEnsemble15.setClassifier(baseLearner);
				imbEnsemble15.setNumIterations(10);
				imbEnsemble15.setUseResampling(true);
				iclassifier=imbEnsemble15;
			break;
		case 16://SBst
				SMOTEBoostV2 SBst=new SMOTEBoostV2();
				//SMOTEBoostM1 smoteboost=new SMOTEBoostM1();
				SBst.setClassifier(baseLearner);
				SBst.setNumIterations(10);
				SBst.setUseResampling(true);
				//SBst.setDebug(true);
				iclassifier=SBst;
			break;
		default://none
				iclassifier = baseLearner;
			break;
		}
		
		return iclassifier;
	}
	
	/**
	 * ������
	 */
	public static void main(String[] args) {
		
		
		String dpath = "";// "D:/database/paper1exp/check/1_CK/";
		List<String> datasetList = new ArrayList<String>();
		System.out.println("Loading file: data_sets.txt");
		//get data set list
		try {
			Scanner fileIn =new Scanner(new BufferedInputStream(
					new FileInputStream(dpath+"data_sets.txt")));
			while (fileIn.hasNext()){
				datasetList.add(fileIn.nextLine());
			}
		} catch (Exception e) {
			System.out.println("Error: can not load data_sets.txt");
		}
		
		String[] learnerList={"C4.5", "RF", "SVM", "Ripper", "IBk", "LR", "NB"};
		String[] imbMethodList={"none", "Bag", "Bst", "US", "OS", "UOS", "SMOTE",
													"COS", "EM1v1", "UBag", "UOBag", "OBag", "SBag", "UBstV2", "OBst", "UOBst", "SBstV2"};
		
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//�������ڸ�ʽ
		if (datasetList.size()>0){
			System.out.println("Experiment starts at"+df.format(new Date()));// new Date()Ϊ��ȡ��ǰϵͳʱ��
		}
		
		//for each data set
		for (String dataName : datasetList){
			System.out.println(dataName+":");
			String[] strArray = dataName.split("--");
			String dataset_name = strArray[0];
			String metriString = strArray[1];
			
			String source = dpath+ sourceDir +dataName + ".arff";
			generateData(source);
			String result = "Dataset,RmFn,Metrics,Learner,ImbMethod,AUC,TP,FN,FP,TN\n";
			
			//repeat m times
			for (int i = 0; i < m_repeat; i++) {
				System.out.println("Repeat0"+i);
				Random rd = new Random(i);
				m_Data.randomize(rd);
				if (m_Data.classAttribute().isNominal()) {
					m_Data.stratify(m_folds);
				}
				
				for (int j = 0; j < m_folds; j++) {
					Instances train = m_Data.trainCV(m_folds, j, rd);
					Instances test = m_Data.testCV(m_folds, j);
					
					for (int mi=13;mi<14;mi++){
						//imbMethodList.length;mi++){
						for (int lnr=0;lnr<learnerList.length;lnr++){
							try {
								Evaluation eval = new Evaluation(m_Data);
								eval.setPriors(train);
								Classifier copyC= get_learning_method(lnr, mi);
								
								if (mi==7){//COS
									CostMatrix matrix = new CostMatrix(2);
									double ratio = checkRatio(train);
									matrix.setElement(0, 0, 0);
									matrix.setElement(0, 1, 1 / (ratio + 1));
									matrix.setElement(1, 0, ratio / (ratio + 1));
									matrix.setElement(1, 1, 0);

									MetaCost meta = new MetaCost();
									meta.setClassifier(copyC);
									meta.setCostMatrix(matrix);
									meta.buildClassifier(train);
									eval.evaluateModel(meta, test);
									//eval.evaluateModel(copyC, test);
								}else {
									copyC.buildClassifier(train);
									eval.evaluateModel(copyC, test);
								}
								double[][] cfmatrix =eval.confusionMatrix();
								int TP = (int)cfmatrix[0][0];
								int FN = (int)cfmatrix[0][1];
								int FP = (int)cfmatrix[1][0];
								int TN = (int)cfmatrix[1][1];
								double auc = eval.areaUnderROC(0);
								result = result+dataset_name+",R"+i+"F"+j+","
										+metriString+","+learnerList[lnr]+","+imbMethodList[mi]+","
										+Utils.doubleToString(auc, 6)+","+TP+","+FN+","+FP+","+TN+"\n";	
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							
						}//baseLearner
					}//imbMethod
				}//n-folds
			}
			System.out.println("## "+df.format(new Date()));
			outputResults(destDir+dataName+"-1.csv", result);
		}

	}	
}
